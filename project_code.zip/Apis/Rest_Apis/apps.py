from django.apps import AppConfig


class RestApisConfig(AppConfig):
    name = 'Rest_Apis'
