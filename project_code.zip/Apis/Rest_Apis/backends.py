from Rest_Apis.models import CustomUser
from django.core import serializers

def authenticate( username=None, password=None):
    if '@' in username:
        kwargs = {'email': username}
    else:
        kwargs = {'username': username}
    try:
        user = CustomUser.objects.get(**kwargs)
        
        return user
    
    except CustomUser.DoesNotExist:
        return None

    def get_user(self, username):
        try:
            return CustomUser.objects.get(pk=username)
        except CustomUser.DoesNotExist:
            return None



