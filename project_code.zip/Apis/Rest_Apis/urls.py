from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from Rest_Apis.views import *



urlpatterns = [
    path('api/register/', RegisterApi.as_view(),name='register'),
    path('api/login/', login),
    path('api/logout/', logout),
    path('api/user/<int:pk>/', View_Delete_Update_user_profile),
    


]