from django.shortcuts import render
from rest_framework.decorators import api_view, permission_classes,authentication_classes
from rest_framework.permissions import AllowAny
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_200_OK
)
from rest_framework.authtoken.models import Token
from rest_framework.parsers import JSONParser 
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt
from rest_framework import generics, permissions
from rest_framework.response import Response
from .serializers import UserSerializer ,RegisterSerializer
from rest_framework.parsers import MultiPartParser, FormParser
from .models import *
from rest_framework.views import APIView
from django.core import serializers
from Rest_Apis.backends import authenticate
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from django.contrib.auth import login as django_login ,logout as django_logout


# Register Api
class RegisterApi(APIView):                             
    parser_classes = (MultiPartParser, FormParser)
    def post(self, request, *args, **kwargs):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(UserSerializer(user).data)


# login Api either with email or username
@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def login(request):                              
    username_email = request.data.get("username_email")
    password = request.data.get("password")
    if username_email is None or password is None:
        return Response({'error': 'Please provide both username and password'},
                        status=HTTP_400_BAD_REQUEST)
    user = authenticate(username=username_email, password=password)
    
    if not user:
        return Response({'error': 'Invalid Credentials'},
                        status=HTTP_404_NOT_FOUND)
    django_login(request,user)
    token, _ = Token.objects.get_or_create(user=user)

    
    return Response({'token': token.key},
                    status=HTTP_200_OK)


# Api for view ,edit ,delete 
@api_view(['GET', 'PUT', 'DELETE','PATCH'])
@authentication_classes([TokenAuthentication,])
@permission_classes([IsAuthenticated])
def View_Delete_Update_user_profile(request,pk):  
    try: 
        user = CustomUser.objects.get(id=pk) 
    except CustomUser.DoesNotExist: 
        return Response({'message': 'The User does not exist'}, status=status.HTTP_404_NOT_FOUND) 
 
    if request.method == 'GET':             # for viewing user profile
        serializer= UserSerializer(user)
        return Response(serializer.data)
    elif request.method == 'PUT':         # for updating user profile
        serializer = UserSerializer(user, data=request.data) 
        if serializer.is_valid(): 
            serializer.save() 
            return Response(serializer.data) 
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST) 
 
    elif request.method == 'DELETE':    # for deleting user profile
        user.delete() 
        return Response({'message': 'User was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    elif request.method == 'PATCH':    # for partial updating user profile
        serializer = UserSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            user_data = serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED) 
        return Response(status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def logout(request):
    django_logout(request)
    return Response({"logout":"user is successfully logout"})